#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>

using namespace std;
int main() {
	string hasloo;
	cout << " Wprowadz haslo: " << endl;
	cin >> hasloo;

	fstream plik_z_haslem;
	plik_z_haslem.open("haslooo.txt", ios::in);
	if (plik_z_haslem.good() == false) {
		cout << "\nNIE MA TAKIEGO PLIKU\n";
	}
	else {
		string haslo1;
		plik_z_haslem >> haslo1;
		plik_z_haslem.close();
		if (haslo1 == hasloo) {
			fstream plik_z_ocenami;
			plik_z_ocenami.open("ocenyy.txt", ios::in);
			if (plik_z_ocenami.good() == false) {
				cout << "W dzienniku nie ma ocen!";
				exit(0);
			}
		
			else {
				int rozmiar;
				plik_z_ocenami >> rozmiar;
				int** oceny;
				oceny = new int* [rozmiar];
				for (int i = 0; i < rozmiar; i++) {
					oceny[i] = new int[rozmiar];
					for (int j = 0; j < rozmiar; j++) {
						plik_z_ocenami >> oceny[i][j];
					}
				}
				plik_z_ocenami.close();
				cout << "Oceny w dzienniku: francuski angielski matematyka fizyka przyroda" << endl;
				for (int i = 0; i < rozmiar; i++) {
					for (int j = 0; j < rozmiar; j++) {

						cout << oceny[i][j] << "\t";
					}
					cout << endl;
				} for (int i = 0; i < rozmiar; i++) {
					delete[] oceny[i];
				}
				delete[] oceny;

			}
		}

		else {
			cout << "Podano b��dne haslo" << endl;
		}
	}
	return 0;
}
		
		