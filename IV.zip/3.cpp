#include <iostream>
#include <iomanip> //u?ywanie manipulator?w (np. set precision, w tym wypadku setw (width) 

using namespace std;

int main()
{
    int n, m, i, j, v1, v2; //liczba wierzcholkow i krawedzi, wspolrz?dne macierzy, wirzcholek startowy i koncowy krawedzi

    cout << "Podaj liczbe wierzolkow i krawedzi: " << endl;
    cin >> n >> m;         // Czytamy liczb? wierzcho?k?w i kraw?dzi

    int** A; // macierz
    A = new int* [n];  // Tworzymy macierz kwadratow? n x n

    for (i = 0; i < n; i++)
    {
        A[i] = new int[n]; // Tworzymy wiersze
    }

    for (i = 0; i < n; i++) // Macierz wype?niamy zerami
    {
        for (j = 0; j < n; j++)
        {
            A[i][j] = 0;
        }
    }
    // Odczytujemy kolejne definicje kraw?dzi

    cout << "Podaj pary wierzcholkow (gdzie liczba par jest rowna liczbie krawedzi): " << endl;

    for (i = 0; i < m; i++)  // p?tla przypisuj?ca parom wierzcho?k?w warto?? 1.
    {
        cin >> v1 >> v2;    // Wierzcho?ek startowy i ko?cowy kraw?dzi
        A[v1][v2] = 1;
    }

    cout << endl;

    // Wypisujemy zawarto?? macierzy s?siedztwa

    cout << "   ";
    for (i = 0; i < n; i++) // petla wypisuj?ca pierwszy wiersz - numery wierzcho?k?w
    {
        cout << setw(3) << i;
    }
    cout << endl << endl;

    for (i = 0; i < n; i++) //p?tla wypisuj?ca pierwsz? kolumne - numery wierzcho?k?w
    {
        cout << setw(3) << i;
        for (j = 0; j < n; j++) // p?tla wypisuj?ca warto?ci przypisane do par wierzcho?k?w
        {
            cout << setw(3) << (int)A[i][j];
        }
        cout << endl;
    }

    // Usuwamy macierz, zwalniamy miejsce w pami?i RAM

    for (i = 0; i < n; i++)
    {
        delete[] A[i];
    }
    delete[] A;

    cout << endl;

    system("pasue");
    return 0;
}