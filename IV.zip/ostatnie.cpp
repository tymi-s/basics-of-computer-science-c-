﻿#include <iostream>
#include <iomanip>
#include <fstream>  

using namespace std;

int main() {
    int n, m, i, j, v1, v2;

    cout << "Podaj nazwe pliku z danymi: " << endl;
    string nazwaPliku;
    cin >> nazwaPliku;


    fstream macierze;
    macierze.open("macierze.txt", ios::in);


    if (macierze.good() == false) {
        cout << "Blad otwierania pliku." << endl;
        return 0;
    }
    else {

        macierze >> n >> m;


        if (n <= -1 || m <= -1) {
            cout << "Niepoprawne dane wejsciowe." << endl;
            return 1;
        }

        int** A = new int* [n];

        for (i = 0; i < n; i++) {
            A[i] = new int[n];
        }

        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                A[i][j] = 0;
            }
        }


        for (i = 0; i < m; i++) {
            macierze >> v1 >> v2;

            if (v1 < 0 || v1 >= n || v2 < 0 || v2 >= n) {
                cout << "Niepoprawna para wierzcholkow." << endl;
                return 1;
            }
            A[v1][v2] = 1;
        }


        macierze.close();

        cout << endl;

        cout << "   ";
        for (i = 0; i < n; i++) {
            cout << setw(3) << i;
        }
        cout << endl << endl;

        for (i = 0; i < n; i++) {
            cout << setw(3) << i;
            for (j = 0; j < n; j++) {
                cout << setw(3) << (int)A[i][j];
            }
            cout << endl;
        }

        // Usuwanie macierzy, zwalnianie miejsca w pamięci

        for (i = 0; i < n; i++) {
            delete[] A[i];
        }
        delete[] A;

        cout << endl;
    }

    return 0;
}
