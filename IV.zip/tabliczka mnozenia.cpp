﻿    #include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n, i, j;
    
    cout << "Podaj wielkosc tabliczki mnozenia: " << endl;
    cin >> n;        

    int** A;
    A = new int* [n]; 

    for (i = 0; i < n; i++) 
    { 
        A[i] = new int[n];
    }

    for (i = 0; i < n; i++) 
    { 
        for (j = 0; j < n; j++) 
        {
            A[i][j] = i*j;
        }
    }

    cout << "   ";
    for (i = 0; i < n; i++) 
    {
        cout << setw(3) << i;
    }
    cout << endl << endl;

    for (i = 0; i < n; i++)
    {
        cout << setw(3) << i;
        for (j = 0; j < n; j++) 
        {
            cout << setw(3) << (int)A[i][j];
        }
        cout << endl;
    }

    for (i = 0; i < n; i++) 
    {
        delete[] A[i];
    }
    delete[] A;

    cout << endl;

    system("pasue");
    return 0;
}